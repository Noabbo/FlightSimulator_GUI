﻿using FlightSimulator.Model;
using FlightSimulator.View.Controls;
using FlightSimulator.ViewModels;
using FlightSimulatorApp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FlightSimulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MainVM vm;
        public MainWindow()
        {
            InitializeComponent();
            this.vm = (Application.Current as App).MainVM;
            DataContext = this.vm;
            enterIP.Text = "";
            enterPort.Text = "";
        }

        private void UserChoice_Click(object sender, RoutedEventArgs e)
        {
            if (this.vm.VMConnectButtons)
            {
                // Make buttons unpressable.
                this.vm.VMConnectButtons = false;
                this.vm.VMDisconButton = false;
                string ip = null;
                int port = -1;
                // Making sure the IP entered is in format
                try
                {
                    var tmp = IPAddress.Parse(enterIP.Text);
                    ip = Convert.ToString(tmp);
                }
                // No IP was entered.
                catch (FormatException)
                {
                    enterIP.Text = "";
                    enterPort.Text = "";
                    this.vm.VMStatus = "No IP Was Found";
                    Status.FontWeight = FontWeights.Bold;
                    // Make connect buttons pressable.
                    Task.Run(async delegate
                    {
                        await Task.Delay(1000);
                        this.vm.VMConnectButtons = true;
                    });
                    return;
                }
                // Invalid IP was entered.
                catch (ArgumentNullException)
                {
                    enterIP.Text = "";
                    enterPort.Text = "";
                    this.vm.VMStatus = "Invalid IP";
                    Status.FontWeight = FontWeights.Bold;
                    // Make connect buttons pressable.
                    Task.Run(async delegate
                    {
                        await Task.Delay(1000);
                        this.vm.VMConnectButtons = true;
                    });
                    return;
                }
                // Making sure the port entered is in format
                try
                {
                    // No port was entered.
                    if (enterPort.Text.Length == 0)
                    {
                        enterIP.Text = "";
                        enterPort.Text = "";
                        this.vm.VMStatus = "No Port Was Found";
                        Status.FontWeight = FontWeights.Bold;
                        // Make connect buttons pressable.
                        Task.Run(async delegate
                        {
                            await Task.Delay(1000);
                            this.vm.VMConnectButtons = true;
                        });
                        return;
                    }
                    port = Convert.ToInt32(enterPort.Text);
                }
                // Invalid port entered.
                catch (FormatException)
                {
                    enterIP.Text = "";
                    enterPort.Text = "";
                    this.vm.VMStatus = "Invalid Port";
                    Status.FontWeight = FontWeights.Bold;
                    // Make connect buttons pressable.
                    Task.Run(async delegate
                    {
                        await Task.Delay(1000);
                        this.vm.VMConnectButtons = true;
                    });
                    return;
                }
                // Both IP and port are valid.
                if ((port > -1) && (ip.Length > 0))
                {
                    // Connect to server.
                    bool isConnected = this.vm.model.Connect(ip, port);
                    // Connection is successful.
                    if (isConnected)
                    {
                        // Change Status accordingly.
                        this.vm.VMStatus = "Connected";
                        Status.FontWeight = FontWeights.Normal;
                        // Make connect buttons unpressable and disconnect button pressable.
                        this.vm.VMConnectButtons = false;
                        this.vm.VMDisconButton = true;
                        return;
                    }
                    // Make connect buttons pressable.
                    Task.Run(async delegate
                    {
                        await Task.Delay(1000);
                        this.vm.VMConnectButtons = true;
                    });
                }
            }
        }

        private void Default_Click(object sender, RoutedEventArgs e)
        {
            if (this.vm.VMConnectButtons)
            {
                // Make buttons unpressable.
                this.vm.VMConnectButtons = false;
                this.vm.VMDisconButton = false;
                // Display default IP and port.
                enterIP.Text = "127.0.0.1";
                enterPort.Text = "5402";
                // Connect to server.
                bool isConnected = this.vm.model.Connect(ConfigurationManager.AppSettings["IP"],
                    Convert.ToInt32(ConfigurationManager.AppSettings["Port"]));
                // Connection is successful.
                if (isConnected)
                {
                    // Change Status accordingly.
                    this.vm.VMStatus = "Connected";
                    Status.FontWeight = FontWeights.Normal;
                    // Make connect buttons unpressable and disconnect button pressable.
                    Task.Run(async delegate
                    {
                        await Task.Delay(1000);
                        this.vm.VMConnectButtons = false;
                        this.vm.VMDisconButton = true;
                    });
                }
                else
                {
                    // Make connect buttons pressable and disconnect button unpressable.
                    Task.Run(async delegate
                    {
                        await Task.Delay(1000);
                        this.vm.VMConnectButtons = true;
                        this.vm.VMDisconButton = false;
                    });
                }
            }
        }

        private void EnterIP_KeyDown(object sender, KeyEventArgs e)
        {
            // The Enter key was pressed.
            if (e.Key == Key.Return)
            {
                if (this.vm.VMConnectButtons)
                {
                    UserChoice_Click(sender, null);
                }
            }
        }
    }
}
