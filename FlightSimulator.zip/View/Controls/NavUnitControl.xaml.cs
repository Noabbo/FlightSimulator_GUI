﻿using FlightSimulatorApp;
using FlightSimulator.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.ComponentModel;

namespace FlightSimulator.View.Controls
{
    /// <summary>
    /// Interaction logic for NavUnitControl.xaml
    /// </summary>
    public partial class NavUnitControl : UserControl
    {
        private MainVM vm;
        private double xStart, yStart, xEnd, yEnd;
        private const double MaxRadius = 85;
        private const double MinRadius = -1 * MaxRadius;
        private bool mousePressed;
        private Storyboard sb;
        public NavUnitControl()
        {
            InitializeComponent();
            this.vm = (Application.Current as App).MainVM;
            DataContext = this.vm;
            // Initializing sliders.
            Throttle.Value = 0;
            Aileron.Value = 0;
            sb = Joystick.sb;
        }

        private void Knob_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!mousePressed)
            {
                xStart = e.GetPosition(sender as Joystick).X;
                yStart = e.GetPosition(sender as Joystick).Y;
                mousePressed = true;
            }
        }

        private void Knob_MouseUp(object sender, MouseButtonEventArgs e)
        {
            mousePressed = false;
            sb.Begin();
            this.vm.VMElevator = Convert.ToString(0);
            this.vm.VMRudder = Convert.ToString(0);
            string command = "set /controls/flight/rudder 0";
            this.vm.SendCommandToList(command);
            command = "set /controls/flight/elevator 0";
            this.vm.SendCommandToList(command);
        }

        private void Knob_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousePressed)
            {
                xEnd = e.GetPosition(sender as Joystick).X;
                yEnd = e.GetPosition(sender as Joystick).Y;
                double dis = Distance(xEnd, xStart, yEnd, yStart);
                // Making sure knob doesn't get out of circle.
                if (dis > MaxRadius)
                {
                    Joystick.knobPosition.X = ((xEnd - xStart) * MaxRadius) / dis;
                    Joystick.knobPosition.Y = ((yEnd - yStart) * MaxRadius) / dis;
                }
                else
                {
                    // Calculating coordinates according to angle and the new dis.
                    Joystick.knobPosition.X = xEnd - xStart;
                    Joystick.knobPosition.Y = yEnd - yStart;
                }
                // Normalize to limits of values and update VM of change for text boxes.
                this.vm.VMRudder = Convert.ToString(Joystick.knobPosition.X / MaxRadius);
                this.vm.VMElevator = Convert.ToString(Joystick.knobPosition.Y / MinRadius);
                // Update the server of change.
                string command = "set /controls/flight/rudder " + this.vm.VMRudder;
                this.vm.SendCommandToList(command);
                command = "set /controls/flight/elevator " + this.vm.VMElevator;
                this.vm.SendCommandToList(command);
            }
        }

        private void Knob_MouseLeave(object sender, MouseEventArgs e)
        {
            Knob_MouseUp(sender, null);
        }

        private double Distance(double endX, double startX, double endY, double startY)
        {
            return Math.Sqrt((endX - startX) * (endX - startX) + (endY - startY) * (endY - startY));
        }

        private void Throttle_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            string command = "set /controls/engines/current-engine/throttle " + Throttle.Value;
            this.vm.SendCommandToList(command);
        }

        private void Aileron_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            string command = "set /controls/flight/aileron " + Aileron.Value;
            this.vm.SendCommandToList(command);
        }
    }
}
