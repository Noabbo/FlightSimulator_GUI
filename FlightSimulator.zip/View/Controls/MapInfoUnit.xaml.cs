﻿using FlightSimulatorApp;
using FlightSimulator.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Maps.MapControl.WPF;
using System.Diagnostics;

namespace FlightSimulator.View.Controls
{
    /// <summary>
    /// Interaction logic for MapInfoUnit.xaml
    /// </summary>
    public partial class MapInfoUnit : UserControl
    {
        private MainVM vm;
        private const int MinLat = -75;
        private const int MaxLat = 75;
        private const int MinLong = -180;
        private const int MaxLong = 180;
        private bool ErLong;
        private bool ErLat;
        public MapInfoUnit()
        {
            InitializeComponent();
            this.vm = (Application.Current as App).MainVM;
            DataContext = this.vm;
            // Initialize error messages.
            OutOfBounds.Content = "";
            ErLatitude.Content = "";
            ErLongitude.Content = "";
            this.ErLong = false;
            this.ErLat = false;
            // Initialize zoom.
            ZoomSetter.Value = ZoomSetter.Minimum;
            InitializeVM();
        }

        internal void InitializeVM()
        {
            // Notify changes to langitude and latitude.
            this.vm.model.PropertyChanged += delegate (Object sender, PropertyChangedEventArgs e)
            {
                try
                {
                    string[] split = e.PropertyName.Split('_');
                    if (split.Length == 2)
                    {
                        string name = split[0];
                        double val = Convert.ToDouble(split[1]);
                        if (name == "Latitude")
                        {
                            // Latitude is within Earth bounds.
                            if ((val >= MinLat) && (val <= MaxLat))
                            {
                                // Change latitude of the pin.
                                this.Dispatcher.Invoke(new Action(() => this.PlanePin.Location =
                                    new Location(val, this.PlanePin.Location.Longitude)));
                                // Remove error warnings.
                                this.Dispatcher.Invoke(new Action(() => Latitude.Text = this.PlanePin.Location.Latitude.ToString()));
                                this.Dispatcher.Invoke(new Action(() => ErLatitude.Content = ""));
                                this.ErLat = false;
                                // No error was found in both longitude and latitude.
                                if (this.ErLong)
                                {
                                    this.Dispatcher.Invoke(new Action(() => OutOfBounds.Content = ""));
                                }
                            }
                            // Error - out of bounds of Earth.
                            else
                            {
                                if (val < MinLat)
                                {
                                    val = MinLat;
                                }
                                else if (val > MaxLat)
                                {
                                    val = MaxLat;
                                }
                                // Change latitude of the pin.
                                this.Dispatcher.Invoke(new Action(() => this.PlanePin.Location =
                                    new Location(val, this.PlanePin.Location.Longitude)));
                                // Dispatching error warnings.
                                this.Dispatcher.Invoke(new Action(() => Latitude.Text = this.PlanePin.Location.Latitude.ToString()));
                                this.Dispatcher.Invoke(new Action(() => OutOfBounds.Content = "Out Of Bounds:"));
                                this.Dispatcher.Invoke(new Action(() => ErLatitude.Content = "Latitude"));
                                this.ErLat = true;
                            }
                        }
                        else if (name == "Longitude")
                        {
                            // Longitude is within Earth bounds.
                            if ((val <= MaxLong) && (val >= MinLong))
                            {
                                // Change longitude of the pin.
                                this.Dispatcher.Invoke(new Action(() => this.PlanePin.Location =
                                    new Location(this.PlanePin.Location.Latitude, val)));
                                // Remove error warnings.
                                this.Dispatcher.Invoke(new Action(() => Longitude.Text = this.PlanePin.Location.Longitude.ToString()));
                                this.Dispatcher.Invoke(new Action(() => ErLongitude.Content = ""));
                                this.ErLong = false;
                                // No error was found in both longitude and latitude.
                                if (!this.ErLat)
                                {
                                    this.Dispatcher.Invoke(new Action(() => OutOfBounds.Content = ""));
                                }
                            }
                            // Error - out of bounds of Earth.
                            else
                            {
                                if (val < MinLong)
                                {
                                    val = MinLong;
                                }
                                else if (val > MaxLong)
                                {
                                    val = MaxLong;
                                }
                                // Change longitude of the pin.
                                this.Dispatcher.Invoke(new Action(() => this.PlanePin.Location =
                                    new Location(this.PlanePin.Location.Latitude, val)));
                                // Dispatching error warnings.
                                this.Dispatcher.Invoke(new Action(() => Longitude.Text = this.PlanePin.Location.Longitude.ToString()));
                                this.Dispatcher.Invoke(new Action(() => OutOfBounds.Content = "Out Of Bounds:"));
                                this.Dispatcher.Invoke(new Action(() => ErLongitude.Content = "Longitude"));
                                this.ErLong = true;
                            }
                        }
                    }
                }
                catch
                {
                    Debug.WriteLine("Problem with changing map!");
                }
            };
        }

        private void Disconnect_Click(object sender, RoutedEventArgs e)
        {
            if (this.vm.VMDisconButton)
            {
                // Reseting error messages.
                OutOfBounds.Content = "";
                ErLatitude.Content = "";
                ErLongitude.Content = "";
                // Reseting zoom.
                ZoomSetter.Value = ZoomSetter.Minimum;
                Task.Run(async delegate
                {
                    await Task.Delay(1000);
                });
                this.vm.model.Disconnect();
            }
        }

        private void ZoomSetter_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // Change zoom level.
            this.Dispatcher.Invoke(new Action(() => WorldMap.ZoomLevel = ZoomSetter.Value));
            // Set the center of the map to be the pin.
            this.Dispatcher.Invoke(new Action(() => WorldMap.Center = new Location(PlanePin.Location)));
        }
    }
}
