﻿using FlightSimulatorApp;
using FlightSimulator.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FlightSimulator.View.Controls
{
    /// <summary>
    /// Interaction logic for DashboardUnit.xaml
    /// </summary>
    public partial class DashboardUnit : UserControl
    {
        private MainVM vm;
        public DashboardUnit()
        {
            InitializeComponent();
            this.vm = (Application.Current as App).MainVM;
            DataContext = this.vm;
        }
    }
}
