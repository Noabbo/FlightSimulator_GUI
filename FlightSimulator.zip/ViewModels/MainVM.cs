﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Threading;
using FlightSimulator.Model;

namespace FlightSimulator.ViewModels
{
    public class MainVM : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public IFlightSimulatorModel model;
        public MainVM(IFlightSimulatorModel flightSimulatorModel)
        {
            this.model = flightSimulatorModel;
            // Notify changes to properties read from server.
            this.model.PropertyChanged += delegate (Object sender, PropertyChangedEventArgs e)
            { NotifyPropertyChanged("VM" + e.PropertyName); };
        }
        public void NotifyPropertyChanged(string propName) =>
           this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));

        // Add command to the list of command for its execution.
        public void SendCommandToList(string command)
        {
            this.model.AddToList(command);
        }

        // Login Properties.
        public string VMStatus
        {
            get
            {
                return model.Status;
            }
            set
            {
                model.Status = value;
            }
        }
        public bool VMConnectButtons
        {
            get
            {
                return model.ConnectButtons;
            }
            set
            {
                model.ConnectButtons = value;
            }
        }
        public bool VMDisconButton
        {
            get
            {
                return model.DisconButton;
            }
            set
            {
                model.DisconButton = value;
            }
        }
        // Reading Dashboard values from server.
        public string VMHeading
        {
            get
            {
                return model.Heading;
            }
        }
        public string VMVerticalSpeed
        {
            get
            {
                return model.VerticalSpeed;
            }
        }
        public string VMGroundSpeed
        {
            get
            {
                return model.GroundSpeed;
            }
        }
        public string VMAirSpeed
        {
            get
            {
                return model.AirSpeed;
            }
        }
        public string VMAltitude
        {
            get
            {
                return model.Altitude;
            }
        }
        public string VMRoll
        {
            get
            {
                return model.Roll;
            }
        }
        public string VMPitch
        {
            get
            {
                return model.Pitch;
            }
        }
        public string VMAltimeter
        {
            get
            {
                return model.Altimeter;
            }
        }
        // Reading longitude and latitude values from server.
        public string VMLongitude
        {
            get
            {
                return model.Longitude;
            }
        }
        public string VMLatitude
        {
            get
            {
                return model.Latitude;
            }
        }
        // Setting NavUnit values and send them to server.
        public string VMRudder
        {
            get
            {
                return model.Rudder;
            }
            set
            {
                model.Rudder = value;
            }
        }
        public string VMElevator
        {
            get
            {
                return model.Elevator;
            }
            set
            {
                model.Elevator = value;
            }
        }
    }
}
