﻿using FlightSimulator;
using FlightSimulator.Model;
using FlightSimulator.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace FlightSimulatorApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public MainVM MainVM { get; internal set; }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            FlightSimulatorModel model = new FlightSimulatorModel();
            MainVM = new MainVM(model);
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }
        public void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            // Ensuring uninterrupted GUI
            e.Handled = true;
        }
    }
}
