﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulator.Model
{
    public interface IFlightSimulatorModel : INotifyPropertyChanged
    {
        // Connect to server.
        bool Connect(string ip, int port);
        // Disconnect from server.
        void Disconnect();
        // Starting the thread which sends commands to server and recieves the appropiate data.
        void Start();
        // Add command to the list of commands to execute.
        void AddToList(string command);
        // Login Properties.
        string Status { get; set; }
        bool ConnectButtons { get; set; }
        bool DisconButton { get; set; }
        // Dashboard Properties.
        string Heading {get; set;}
        string VerticalSpeed { get; set; }
        string GroundSpeed { get; set; }
        string AirSpeed { get; set; }
        string Altitude { get; set; }
        string Roll { get; set; }
        string Pitch { get; set; }
        string Altimeter { get; set; }
        // Map Properties.
        string Longitude { get; set; }
        string Latitude { get; set; }
        // Joystick Properties.
        string Rudder { get; set; }
        string Elevator { get; set; }
    }
}
