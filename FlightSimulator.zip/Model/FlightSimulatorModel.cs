﻿using System;
using System.Timers;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Net.Sockets;
using System.Net;

namespace FlightSimulator.Model
{
    public class FlightSimulatorModel : IFlightSimulatorModel
    {
        public event PropertyChangedEventHandler PropertyChanged;
        volatile bool stop;
        LinkedList<string> Commands;
        private TcpClient tcpClient;
        private NetworkStream stream;
        private StreamReader reader;
        private StreamWriter writer;
        Mutex mutex;
        private System.Timers.Timer timer;
        private const int Timeout_Milsec = 10000;
        private const string HeadingGetPath = "get /instrumentation/heading-indicator/indicated-heading-deg\n";
        private const string VerticalSpeedGetPath = "get /instrumentation/gps/indicated-vertical-speed\n";
        private const string GroundSpeedGetPath = "get /instrumentation/gps/indicated-ground-speed-kt\n";
        private const string AirSpeedGetPath = "get /instrumentation/airspeed-indicator/indicated-speed-kt\n";
        private const string AltitudeGetPath = "get /instrumentation/gps/indicated-altitude-ft\n";
        private const string RollGetPath = "get /instrumentation/attitude-indicator/internal-roll-deg\n";
        private const string PitchGetPath = "get /instrumentation/attitude-indicator/internal-pitch-deg\n";
        private const string AltimeterGetPath = "get /instrumentation/altimeter/indicated-altitude-ft\n";
        private const string LatitudeGetPath = "get /position/latitude-deg\n";
        private const string LongitudeGetPath = "get /position/longitude-deg\n";
        public FlightSimulatorModel()
        {
            this.stop = true;
            this.mutex = new Mutex();
            this.timer = new System.Timers.Timer(Timeout_Milsec);
            ResetVariables();
        }

        public void NotifyPropertyChanged(string propName) =>
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        
        public bool Connect(string ip, int port)
        {
            // Create a TcpClient.
            this.tcpClient = new TcpClient();
            try
            {
                // Connecting to server through valid IP and port.
                IPAddress IP = IPAddress.Parse(ip);
                this.tcpClient.Connect(IP, port);
            }
            catch
            {
                Status = "Please Try Again";
                Debug.WriteLine("unable to connect - try again");
                return false;
            }
            // Set streams.
            this.stream = tcpClient.GetStream();
            this.reader = new StreamReader(this.stream);
            this.writer = new StreamWriter(this.stream)
            {
                AutoFlush = true
            };
            // Set timer for timeout.
            this.timer.Elapsed += OnTimedEvent;
            this.timer.AutoReset = false;
            // Client is connected to server.
            this.stop = false;
            Start();
            return true;
        }

        // Defining event to happen if server doesn't respond after 10 seconds.
        private void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            this.Status = "Timeout!";
        }

        public void Disconnect()
        {
            if (!stop)
            {
                stop = true;
                // Disconnect from server.
                this.stream.Close();
                this.reader.Close();
                this.writer.Close();
                this.tcpClient.Close();
                ResetVariables();
            }
        }

        private void ResetVariables()
        {
            InitializeList();
            // Set enabling of buttons.
            this.ConnectButtons = true;
            this.DisconButton = false;
            Status = "Disconnected";
            Heading = Convert.ToString(0);
            VerticalSpeed = Convert.ToString(0);
            GroundSpeed = Convert.ToString(0);
            AirSpeed = Convert.ToString(0);
            Altitude = Convert.ToString(0);
            Roll = Convert.ToString(0);
            Pitch = Convert.ToString(0);
            Altimeter = Convert.ToString(0);
            Longitude = Convert.ToString(34.8854);
            Latitude = Convert.ToString(32.0055);
            Rudder = Convert.ToString(0);
            Elevator = Convert.ToString(0);
        }

        private void InitializeList()
        {
            this.Commands = new LinkedList<string>();
            this.Commands.AddLast(HeadingGetPath);
            this.Commands.AddLast(VerticalSpeedGetPath);
            this.Commands.AddLast(GroundSpeedGetPath);
            this.Commands.AddLast(AirSpeedGetPath);
            this.Commands.AddLast(AltitudeGetPath);
            this.Commands.AddLast(RollGetPath);
            this.Commands.AddLast(PitchGetPath);
            this.Commands.AddLast(AltimeterGetPath);
            this.Commands.AddLast(LongitudeGetPath);
            this.Commands.AddLast(LatitudeGetPath);
        }
        public void Start()
        {
            new Thread(delegate ()
            {
                while (!stop)
                {
                    try
                    {
                        bool isSet = false;
                        string tmp;
                        double test = 0;
                        this.timer.Interval = Timeout_Milsec;
                        this.mutex.WaitOne();
                        string command = this.Commands.First();
                        this.mutex.ReleaseMutex();
                        if (command != null)
                        {
                            timer.Start();
                            // Send command to server.
                            this.writer.WriteLine(command);
                            tmp = this.reader.ReadLine();
                            timer.Stop();
                            switch (command)
                            {
                                case HeadingGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        Heading = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        Heading = Convert.ToString(value);
                                    }
                                    break;
                                case VerticalSpeedGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        VerticalSpeed = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        VerticalSpeed = Convert.ToString(value);
                                    }
                                    break;
                                case GroundSpeedGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        GroundSpeed = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        GroundSpeed = Convert.ToString(value);
                                    }
                                    break;
                                case AirSpeedGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        AirSpeed = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        AirSpeed = Convert.ToString(value);
                                    }
                                    break;
                                case AltitudeGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        Altitude = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        Altitude = Convert.ToString(value);
                                    }
                                    break;
                                case RollGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        Roll = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        Roll = Convert.ToString(value);
                                    }
                                    break;
                                case PitchGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        Pitch = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        Pitch = Convert.ToString(value);
                                    }
                                    break;
                                case AltimeterGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        Altimeter = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to three decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 3);
                                        Altimeter = Convert.ToString(value);
                                    }
                                    break;
                                case LongitudeGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        Longitude = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to six decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 6);
                                        Longitude = Convert.ToString(value);
                                    }
                                    break;
                                case LatitudeGetPath:
                                    // Server sent error or an invalid value.
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                        Latitude = "ERR";
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("read:" + tmp);
                                        // Round number to six decimal places.
                                        double value = Math.Round(Convert.ToDouble(tmp), 6);
                                        Latitude = Convert.ToString(value);
                                    }
                                    Thread.Sleep(250);
                                    break;
                                // Set Command.
                                default:
                                    isSet = true;
                                    if (!double.TryParse(tmp, out test))
                                    {
                                        Debug.WriteLine("ERR");
                                    }
                                    // Server sent a valid value.
                                    else
                                    {
                                        Debug.WriteLine("set value:" + tmp);
                                    }
                                    break;
                            }
                            // Timeout has ended.
                            if (this.Status == "Timeout!")
                            {
                                this.Status = "Connected";
                            }
                            this.mutex.WaitOne();
                            this.Commands.Remove(command);
                            this.mutex.ReleaseMutex();
                            if (!isSet)
                            {
                                // Add the get command again list.
                                this.mutex.WaitOne();
                                this.Commands.AddLast(command);
                                this.mutex.ReleaseMutex();
                            }
                        }
                        else
                        {
                            Debug.WriteLine("Command problem!");
                        }
                    }
                    catch
                    {
                        timer.Stop();
                        Debug.WriteLine("Connection problem!");
                        this.Disconnect();
                    }
                }
            }).Start();
        }

        public void AddToList(string command)
        {
            this.mutex.WaitOne();
            this.Commands.AddFirst(command);
            this.mutex.ReleaseMutex();
        }

        private string status;
        private bool connectButtons;
        private bool disconButton;
        public string Status
        {
            get
            {
                return status;
            }
            set
            {
                status = value;
                NotifyPropertyChanged("Status");
            }
        }
        public bool ConnectButtons
        {
            get
            {
                return connectButtons;
            }
            set
            {
                connectButtons = value;
                NotifyPropertyChanged("ConnectButtons");
            }
        }
        public bool DisconButton
        {
            get
            {
                return disconButton;
            }
            set
            {
                disconButton = value;
                NotifyPropertyChanged("DisconButton");
            }
        }
        // Defining all properties of the simulator.
        private string heading;
        private string verticalSpeed;
        private string groundSpeed;
        private string airSpeed;
        private string altitude;
        private string roll;
        private string pitch;
        private string altimeter;
        private string longitude;
        private string latitude;
        private string rudder;
        private string elevator;
        public string Heading
        {
            get
            {
                return heading;
            } 
            set
            {
                heading = value;
                NotifyPropertyChanged("Heading");
            }
        }
        public string VerticalSpeed
        {
            get
            {
                return verticalSpeed;
            }
            set
            {
                verticalSpeed = value;
                NotifyPropertyChanged("VerticalSpeed");
            }
        }
        public string GroundSpeed
        {
            get
            {
                return groundSpeed;
            }
            set
            {
                groundSpeed = value;
                NotifyPropertyChanged("GroundSpeed");
            }
        }
        public string AirSpeed
        {
            get
            {
                return airSpeed;
            }
            set
            {
                airSpeed = value;
                NotifyPropertyChanged("AirSpeed");
            }
        }
        public string Altitude
        {
            get
            {
                return altitude;
            }
            set
            {
                altitude = value;
                NotifyPropertyChanged("Altitude");
            }
        }
        public string Roll
        {
            get
            {
                return roll;
            }
            set
            {
                roll = value;
                NotifyPropertyChanged("Roll");
            }
        }
        public string Pitch
        {
            get
            {
                return pitch;
            }
            set
            {
                pitch = value;
                NotifyPropertyChanged("Pitch");
            }
        }
        public string Altimeter
        {
            get
            {
                return altimeter;
            }
            set
            {
                altimeter = value;
                NotifyPropertyChanged("Altimeter");
            }
        }
        public string Longitude
        {
            get
            {
                return longitude;
            }
            set
            {
                longitude = value;
                NotifyPropertyChanged("Longitude");
                NotifyPropertyChanged("Longitude_" + value);
            }
        }
        public string Latitude
        {
            get
            {
                return latitude;
            }
            set
            {
                latitude = value;
                NotifyPropertyChanged("Latitude");
                NotifyPropertyChanged("Latitude_" + value);
            }
        }
        public string Rudder
        {
            get
            {
                return rudder;
            }
            set
            {
                rudder = value;
                NotifyPropertyChanged("Rudder");
            }
        }
        public string Elevator
        {
            get
            {
                return elevator;
            }
            set
            {
                elevator = value;
                NotifyPropertyChanged("Elevator");
            }
        }
    }
}
